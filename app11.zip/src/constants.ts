export const GENRES = [
  'Rock', 'Electronic', 'Hip Hop', 'Jazz', 'Indie', 'Classical', 'Chillout',
  'Ambient', 'Folk', 'Metal', 'Latin', 'R&B', 'Reggae', 'Punk',
  'Country', 'House', 'Blues', 'Cinematic', 'Pop', 'Acoustic'
];